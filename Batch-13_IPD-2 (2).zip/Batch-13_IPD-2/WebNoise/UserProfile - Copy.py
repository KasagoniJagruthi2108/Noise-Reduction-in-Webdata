class UserProfile:   
    
    
    def getServer(self):
        return self.server

    def setServer(self, server):
        self.server = server

    def getUser(self):
        return self.user

    def setUser(self, user):
        self.user = user

    def getWebpage(self):
        return self.webpage

    def setWebpage(self, webpage):
        self.webpage = webpage

    def getDate(self):
        return self.date

    def setDate(self, date):
        self.date = date

    def getURL(self):
        return self.url

    def setURL(self, url):
        self.url = url

    def setFrequency(self,frequency):
        self.frequency = frequency;

    def getFrequency(self):
        return self.frequency;

    def setWeight(self,weight):
        self.weight = weight;

    def getWeight(self):
        return self.weight;

    def setPageDepth(self,pagedepth):
        self.pagedepth = pagedepth;

    def getPageDepth(self):
        return self.pagedepth;

  
